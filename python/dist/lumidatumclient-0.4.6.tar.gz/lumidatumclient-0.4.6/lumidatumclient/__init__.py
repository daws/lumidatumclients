from lumidatumclient.classes import LumidatumClient

version = '0.4.6'
