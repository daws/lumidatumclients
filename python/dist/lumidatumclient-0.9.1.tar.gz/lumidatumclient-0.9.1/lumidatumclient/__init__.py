from lumidatumclient.classes import LumidatumClient

__version__ = '0.9.1'
